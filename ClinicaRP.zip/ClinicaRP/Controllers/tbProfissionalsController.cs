﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ClinicaRP.Models;
using Microsoft.AspNet.Identity;

namespace ClinicaRP.Controllers
{
    [Authorize]
    public class tbProfissionalsController : Controller
    {
        private Model1 db = new Model1();
      
         public enum Plan
         {
             MédicoTotal = 1,
             MédicoParcial = 2,
             Nutricional = 3,
             Especial = 4
         }

        // GET: tbProfissionals
        //[Authorize(Roles = "Gerente", "Médico")]
        public ActionResult Index()
        {
           var tbProfissional = db.tbProfissional.Include(t => t.tbCidade).Include(t => t.tbContrato).Include(t => t.tbTipoAcesso);
           return View(tbProfissional.ToList());
            /*
            IQueryable<tbProfissional> tbProfissional = null;

            if (User.IsInRole("Gerente")) {
                tbProfissional = db.tbProfissional.Include(t => t.tbCidade).Include(t => t.tbContrato).Include(t => t.tbTipoAcesso);
                return View(tbProfissional.ToList());
            }        
            // LINQ
            else
            {
                if (User.IsInRole("Médico")) {
                    //var k = (from c in db.tbProfissional
                    //         where ((Plan)c.tbContrato.IdPlano == Plan.MédicoTotal)
                    //         select c).ToList().Select(x => new tbProfissional() { Bairro = x.Bairro, CEP = x.CEP }).ToList();
                    var k = (from c in db.tbProfissional
                             where ((Plan)c.tbContrato.IdPlano == Plan.MédicoTotal)
                             select new ParteProfissional() { Bairro = c.Bairro, CEP = c.CEP, CPF = c.CPF, Nome = c.Nome }).ToList();
                    return View("Index2", k);
                }
            }
            return View(tbProfissional.ToList());*/
            // var k = (from c in db.tbProfissional
            //         where ((Plan)c.tbContrato.IdPlano == Plan.MédicoTotal)
            //         select c).ToList();
            // return View(k);

            //var k = (from c in db.tbProfissional
            //         where (c.tbContrato.IdPlano == 1)
            //         select c).ToList();
            //return View(k);

            // var k = from c in db.tbProfissional
            //         where ((Plan)c.tbContrato.IdPlano == Plan.MédicoParcial)
            //           select c).ToList();
            //  return View(k);
        }

        // GET: tbProfissionals/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbProfissional tbProfissional = db.tbProfissional.Find(id);
            if (tbProfissional == null)
            {
                return HttpNotFound();
            }
            return View(tbProfissional);
        }

        // GET: tbProfissionals/Create
        public ActionResult Create()
        {
            ViewBag.IdCidade = new SelectList(db.tbCidade, "IdCidade", "Nome");
            ViewBag.IdPlano = new SelectList(db.tbPlano, "IdPlano", "Nome");
            ViewBag.IdTipoAcesso = new SelectList(db.tbTipoAcesso, "IdTipoAcesso", "Nome");
            return View();
        }

        // POST: tbProfissionals/Create
        // Para se proteger de mais ataques, habilite as propriedades específicas às quais você quer se associar. Para 
        // obter mais detalhes, veja https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "IdProfissional,IdTipoProfissional,IdContrato,IdTipoAcesso,IdCidade,Nome,CPF,CRM_CRN,Especialidade,Logradouro,Numero,Bairro,CEP,Cidade,Estado,DDD1,DDD2,Telefone1,Telefone2,Salario")] tbProfissional tbProfissional, [Bind(Include ="IdPlano")] tbContrato tbContrato)
        {
            //try-catch
            try
            {
                ModelState.Remove("IdUser");
                if (ModelState.IsValid)
                {
                    /// contrato ///
                    tbContrato.DataInicio = DateTime.UtcNow;
                    tbContrato.DataFim = tbContrato.DataInicio.Value.AddMonths(1);
                    db.tbContrato.Add(tbContrato);
                    db.SaveChanges();

                    /// profissional ///
                    tbProfissional.IdContrato = tbContrato.IdContrato;
                    tbProfissional.IdUser = User.Identity.GetUserId();
                    db.tbProfissional.Add(tbProfissional);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            catch (DataException dex)
            {
                //ModelState.AddModelError("", "Verifique com o administrador");
                ModelState.AddModelError("", dex.Message);
                ViewBag.Erro = dex.Message;
            }

            ViewBag.IdCidade = new SelectList(db.tbCidade, "IdCidade", "Nome");
            ViewBag.IdPlano = new SelectList(db.tbPlano, "IdPlano", "Nome");
            ViewBag.IdTipoAcesso = new SelectList(db.tbTipoAcesso, "IdTipoAcesso", "Nome", tbProfissional.IdTipoAcesso);
            return View(tbProfissional);
        }

        // GET: tbProfissionals/Edit/5
        [AllowAnonymous]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbProfissional tbProfissional = db.tbProfissional.Find(id);
            if (tbProfissional == null)
            {
                return HttpNotFound();
            }
            ViewBag.IdCidade = new SelectList(db.tbCidade, "IdCidade", "Nome");
            ViewBag.IdPlano = new SelectList(db.tbPlano, "IdPlano", "Nome");
            ViewBag.IdTipoAcesso = new SelectList(db.tbTipoAcesso, "IdTipoAcesso", "Nome", tbProfissional.IdTipoAcesso);
            return View(tbProfissional);
        }

        // POST: tbProfissionals/Edit/5
        // Para se proteger de mais ataques, habilite as propriedades específicas às quais você quer se associar. Para 
        // obter mais detalhes, veja https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult Editpost(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbProfissional tbProfissional = db.tbProfissional.Find(id);
            if (TryUpdateModel(tbProfissional, "", new string[] { "IdCidade", "Nome", "CPF", "CRM_CRN", "Especialidade", "Logradouro", "Numero", "Bairro", "CEP", "Cidade", "Estado", "DDD1", "DDD2", "Telefone1", "Telefone2", "Salario" }))
            {
                try
                {
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                catch (DataException /* dex */)
                {
                    ModelState.AddModelError("", "unable to save <changes. Try again, and if the problem persisits, see your sytem administration.");
                }
            
            }
            ViewBag.IdCidade = new SelectList(db.tbCidade, "IdCidade", "Nome");
            ViewBag.IdPlano = new SelectList(db.tbPlano, "IdPlano", "Nome");
            ViewBag.IdTipoAcesso = new SelectList(db.tbTipoAcesso, "IdTipoAcesso", "Nome", tbProfissional.IdTipoAcesso);
            return View(tbProfissional);
        }

        // GET: tbProfissionals/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbProfissional tbProfissional = db.tbProfissional.Find(id);
            if (tbProfissional == null)
            {
                return HttpNotFound();
            }
            return View(tbProfissional);
        }

        // POST: tbProfissionals/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbProfissional tbProfissional = db.tbProfissional.Find(id);
            db.tbProfissional.Remove(tbProfissional);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
