﻿namespace ClinicaRP.Controllers
{
    internal class IdentityUseRole
    {
    }
}